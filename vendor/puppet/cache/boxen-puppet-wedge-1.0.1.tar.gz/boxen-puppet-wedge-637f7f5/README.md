# Wedge Puppet Module for Boxen

## Usage

```puppet
include wedge
```

## Required Puppet Modules

* boxen

