# wkhtmltopdf Puppet Module for Boxen

Requires the following boxen modules:

* `boxen`
* `homebrew`

## Usage

```puppet
include wkhtmltopdf
```