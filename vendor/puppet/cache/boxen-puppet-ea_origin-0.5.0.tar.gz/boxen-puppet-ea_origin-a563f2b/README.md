puppet-ea-origin
====

EA Origin install script for Github Boxen

````
include ea_origin
````

### Required Puppet Modules

- boxen

### Developing

Write code and run ````script/cibuild.````